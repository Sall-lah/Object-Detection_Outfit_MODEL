import cv2
cv2.ocl.setUseOpenCL(False)
import numpy as np
import webcolors
from sklearn.cluster import KMeans
from .loadModel import model

# Helper: find nearest color name
# Helper: find nearest color name
def rgb_to_name(rgb_color):
    r, g, b = int(rgb_color[0]), int(rgb_color[1]), int(rgb_color[2])

    color_dict = {
        "black": "#000000", "white": "#FFFFFF", "gray": "#808080", "lightgray": "#D3D3D3", "darkgray": "#505050", 
        "red": "#FF0000", "darkred": "#8B0000", "orange": "#FFA500", "brown": "#A52A2A", "yellow": "#FFFF00",
        "gold": "#FFD700", "green": "#008000", "lightgreen": "#90EE90", "cyan": "#00FFFF", "blue": "#0000FF",
        "navy": "#000080", "purple": "#800080", "violet": "#EE82EE", "pink": "#FFC0CB", "lightpink": "#FFB6C1",
        "beige": "#F5F5DC", "cream": "#FFFDD0", "khaki": "#F0E68C", "tan": "#D2B48C", "wheat": "#F5DEB3",
        "lightyellow": "#FFFFE0",
    }

    # Find the closest match
    min_diff = float('inf')
    closest_name = "unknown"
    for name, hex_val in color_dict.items():
        rc, gc, bc = webcolors.hex_to_rgb(hex_val)
        diff = (r - rc) ** 2 + (g - gc) ** 2 + (b - bc) ** 2
        if diff < min_diff:
            min_diff = diff
            closest_name = name

    return closest_name

# Main Detection Fucntion
def detect(frame_color):
    # Read the image
    # frame_color = cv2.imread(image)

    if frame_color is None:
        raise FileNotFoundError("Image not found!")

    gray_frame = cv2.cvtColor(frame_color, cv2.COLOR_BGR2GRAY)
    gray_frame = cv2.cvtColor(gray_frame, cv2.COLOR_GRAY2BGR)

    # Run YOLO detection
    results = model(gray_frame)

    # Find the box with the highest confidence 
    best_box = None
    best_conf = 0
    best_cls = None

    for r in results:
        for box in r.boxes:
            conf = float(box.conf[0])
            if conf > best_conf:
                best_conf = conf
                best_box = box
                best_cls = int(box.cls[0])  # class index

    # Crop the detected region 
    if best_box is not None:
        x1, y1, x2, y2 = map(int, best_box.xyxy[0])
        w, h = x2 - x1, y2 - y1
        fraction = 0.7
        cx1 = x1 + int(w * (1 - fraction) / 2)
        cx2 = x2 - int(w * (1 - fraction) / 2)
        cy1 = y1 + int(h * (1 - fraction) / 2)
        cy2 = y2 - int(h * (1 - fraction) / 2)

        crop_color = frame_color[cy1:cy2, cx1:cx2]

        # # Convert to RGB for K-Means
        crop_rgb = cv2.cvtColor(crop_color, cv2.COLOR_BGR2RGB)
    
        # Run K-Means
        pixels = crop_rgb.reshape(-1, 3)
        kmeans = KMeans(n_clusters=3, random_state=0, algorithm="lloyd")
        kmeans.fit(pixels)

        colors = np.array(kmeans.cluster_centers_, dtype='uint8')
        labels, counts = np.unique(kmeans.labels_, return_counts=True)
        dominant_color = colors[np.argmax(counts)]
        print(dominant_color, labels, counts);

        # Get color name 
        color_name = rgb_to_name(dominant_color)

        return "success", model.names[best_cls], color_name, "Object detected sucsessfully"
    else:
        return "failed", "unknown", "unknown", "No object detected"
